<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;

class pluginextension extends Controller
{
    public function index(){
        return view('pluginextension');
    }
}