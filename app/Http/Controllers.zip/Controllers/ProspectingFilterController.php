<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\CusList;
use App\Models\UserPlan;
use App\Models\ProspectingList;
use App\Models\History;
use App\Models\SaveHistory;
use DB;
use Session;
class ProspectingFilterController extends Controller
{
   public function prospecting_filter($id)
    { 
        
        if($id) { ?>
        <script>
            $(document).ready(function() {
   
              var table = $('#example2').DataTable({ 
                    select: false,
                    "columnDefs": [{
                        className: "Name", 
                        "targets":[0],
                        "visible": false,
                        "searchable":false
                    }]
                });//End of create main table
            });
        </script>
       <table id="example2" class="display pt-4 mb-4" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th> </th>
                <th> </th>
                <th>Name</th>
                <th>Contacts</th>
                <th>company</th>
                <th>Action</th>
            </tr>
        </thead> 
        <tbody>
            <?php 
            $api_secret = env('API_SECRET'); 
           $api_url = env('API_URL'); 
        $url = $api_url.''."fetchSpecific";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);

        $data = array(
            "api_secret" => $api_secret,
            "row_id" => $id
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        $contents = curl_exec($ch);
        $list_contact = json_decode($contents,true);
        curl_close($ch);
 // echo '<pre>'; print_r($list_contact); echo '</pre>';
 //           exit;
    if($list_contact){
    
            ?>
              <tr>
                <td><?php //echo $row['full_name']; ?></td>
                <td><input type="checkbox" class="filter_prospecting" name="check_detail"></td>
                <td><?php echo $list_contact['full_name'];?></td>
                <td><p><strong>Company Website:</strong> <?php echo $list_contact['job_company_website']; ?></p>
                    <p><strong> Company Facebook url :</strong> <?php echo $list_contact['job_company_facebook_url']; ?></p>
                    <p><strong>Company Twitter url :</strong><?php echo $list_contact['job_company_twitter_url']; ?></p>
                   <p><strong>Location:</strong> <?php echo $list_contact['job_company_location_name']; ?></p>
                    <p><strong>locality:</strong><?php echo $list_contact['job_company_location_locality']; ?></p>
                    <p><strong>Region:</strong><?php echo $list_contact['job_company_location_region']; ?></p>
                    <p><strong>Country:</strong><?php echo $list_contact['job_company_location_country']; ?></p>
                    <p> <strong>Location Name:</strong><?php echo $list_contact['location_name']; ?></p>
                </td>
                <td><p><?php echo $list_contact['job_company_name']; ?></p></td>
                <td> <button class="btn app-btn-primary float-end" data-bs-toggle="modal" data-bs-target="#filtersaveModal">Show Details</button> </td>
              </tr>  
                <?php  } ?>
             <!-- end tag -->
            </tbody>
        </table>
        <?php
        }else{?>
            <h1>No Result Found !</h1> 
       <?php }
    }


    // prospecting insert data
    public function add_prospecting(Request $request)
    {
        $user_id = Auth::id();
        $user_credit = $request->credit;
        $user_contact = $request->list_contact;
        $list_id = $request->list_id;

        $create_prospecting = ProspectingList::create([
                    'list_id'    =>  $list_id,
                    'user_id' =>  $user_id,
                    'full_name' =>  $request->full_name,
                    'linkedin_url' =>  $request->linkedin_url,
                    'facebook_url' =>  $request->facebook_url,
                    'twitter_url' =>  $request->twitter_url,
                    'github_url' =>  $request->github_url,
                    'work_email' =>  $request->work_email,
                    'mobile_phone' =>  $request->mobile_phone,
                    'job_title' =>  $request->job_title,
                    'job_company_name' =>  $request->job_company_name,
                    'new_departments' =>  $request->departments
                ]);
        //check if plan is create
        if($create_prospecting){
            $user_id = Auth::id();
            $update_plan = UserPlan::where('user_id', $user_id)
                ->update([
                    'used_credits'    =>  $user_credit,
                ]); 
            $updat_contact = CusList::where('id', $list_id)
                ->update([
                    'list_contacts'    =>  $user_contact,
                ]);
        }

        return redirect()->back()->with('status','Save detail your list Successfully');

    }

//   Show prospecting data

public function compainy_details(Request $request){
    
$api_secret = env('API_SECRET'); 
$api_url = env('API_URL'); 
    $company_id = $request->company_id;
    // call api for get specific company data
       $url = $api_url.''."fetchSpecific";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);

        $data = array(
            "api_secret" => $api_secret,
            "row_id" =>  $company_id
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        $contents = curl_exec($ch);
        $company_list = json_decode($contents);
        curl_close($ch);
       // echo '<pre>'; print_r($company_list); echo '</pre>';
       if($company_list){ ?>
       <input type="hidden" name="full_name" value="<?php if(isset($company_list->full_name)){ echo $company_list->full_name;}?>">
       <input type="hidden" name="linkedin_url" value="<?php if(isset($company_list->linkedin_url)) { echo $company_list->linkedin_url;}?>">
       <input type="hidden" name="facebook_url" value="<?php if(isset($company_list->facebook_url)){echo $company_list->facebook_url; }?>">
       <input type="hidden" name="twitter_url" value="<?php if(isset($company_list->twitter_url)) {echo $company_list->twitter_url; }?>">
       <input type="hidden" name="github_url" value="<?php if(isset($company_list->github_url)) {echo $company_list->github_url;}?>">
       <input type="hidden" name="work_email" value="<?php if(isset($company_list->work_email)) {echo $company_list->work_email;} ?>">
       <input type="hidden" name="mobile_phone" value="<?php  if(isset($company_list->mobile_phone)) {echo $company_list->mobile_phone ;} ?>">
       <input type="hidden" name="job_title" value="<?php  if(isset($company_list->job_title)){echo $company_list->job_title;} ?>">
       <input type="hidden" name="job_company_name" value="<?php if(isset($company_list->job_company_name)) {echo $company_list->job_company_name; } ?>">
       <input type="hidden" name="departments" value="<?php  if(isset($company_list->industry)) {echo $company_list->industry; } ?>">
       <?php } else { 
            echo "No data Found from Api responce.";
        } ?>
<?php }
    public function prospecting_list($id){
         $prospect_list = ProspectingList::where('list_id', $id)->get();
        return view('customer.prospecting_list',compact('prospect_list'));
    }
    echo "heloo";
    public function prospecting_lists(){
        $user_id = Auth::id();
         $prospect_list = ProspectingList::where('user_id', $user_id)->get();
        return view('customer.prospecting_list',compact('prospect_list'));
    }
    
    //Function for filters
    public function search_filter(Request $request){

        
         $page = !empty($request['page'])?$request['page']:1;
        //
        //echo $page;
     $api_secret = env('API_SECRET'); 
       $api_url = env('API_URL'); 

        $url =  $api_url.''."fetchAll";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);

        $data = array(
            "api_secret" => $api_secret,
            "page" => $page,
            "limit" => 500,
            "order" => "ASC",
            "hasMore"=> true,

        );
        
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        $contents = curl_exec($ch);
        $company_list1 = json_decode($contents);
    //     echo "<pre>";
     
       
        $job_company_name =!empty($request->job_company_name)?$request->job_company_name:$request->all_filter;

         $job_company_location_name =!empty($request->job_company_location_name)?$request->job_company_location_name:$request->all_filter;
         $industry =!empty($request->job_company_industry)?$request->job_company_industry:$request->all_filter;
         $job_company_size =!empty($request->job_company_size)?$request->job_company_size:$request->all_filter;
         $job_company_founded =!empty($request->job_company_founded)?$request->job_company_founded:$request->all_filter;
          $contact_name =!empty($request->contact_name)?$request->contact_name:$request->all_filter;
          $job_company_location_country =!empty($request->job_company_location_country)?$request->job_company_location_country:$request->all_filter;
           $job_title_role =!empty($request->job_title_role)?$request->job_title_role:$request->all_filter;
           $seniority =!empty($request->seniority)?$request->seniority:$request->all_filter;
          
            $job_title =!empty($request->job_title)?$request->job_title:$request->all_filter;
          
        if(!empty($job_company_name) && $request->filter_type == "job_company_name"){
             
                    $company_list1 = collect((array)$company_list1->data)->whereIn('job_company_name',$job_company_name)->all();
             
        }elseif(!empty($job_company_location_name)  && $request->filter_type == "job_company_location_name"){
        
            $company_list1 = collect((array)$company_list1->data)->whereIn('job_company_location_name', $job_company_location_name)->all();
         
        }elseif(!empty($industry)  && $request->filter_type == "job_company_industry"){
         
            $company_list1 = collect((array)$company_list1->data)->whereIn('job_company_industry',$industry)->all();
         
        }elseif(!empty($job_company_size)  && $request->filter_type == "job_company_size"){
            
            $company_list1 = collect((array)$company_list1->data)->whereIn('job_company_size',$job_company_size)->all();
        }elseif(!empty($job_company_founded)  && $request->filter_type == "job_company_founded"){
            
            $company_list1 = collect((array)$company_list1->data)->whereIn('job_company_founded',$job_company_founded)->all();
     
        }elseif(!empty($contact_name)  && $request->filter_type == "contact_name" &&  $request->search_type == 1){
           
            $company_list1 = collect((array)$company_list1->data)->whereIn('job_title',$contact_name)->all();
          
        }elseif(!empty($job_company_location_country)  && $request->filter_type == "job_company_location_country"){
           
            $company_list1 = collect((array)$company_list1->data)->whereIn('job_company_location_country',$job_company_location_country)->all();

        }elseif(!empty($job_title_role)  && $request->filter_type == "job_title_role"){
          
            $company_list1 = collect((array)$company_list1->data)->whereIn('job_title_role',$job_title_role)->all();
     
        }elseif(!empty($seniority)  && $request->filter_type == "seniority"){
          // die('here');
            $company_list1 = collect((array)$company_list1->data)->whereIn('job_title_role',$seniority)->all();
     
        }elseif(!empty($job_title)  && $request->filter_type == "job_title"){
           
            $company_list1 = collect((array)$company_list1->data)->whereIn('job_title',$job_title)->all();
     
        }
        
        $checkUserhistory = History::where('user_id',Auth::id())->first();
        $filtertype = $request['history'];
     //  
       if($page == 1){
        if(!empty($checkUserhistory)){
            foreach($filtertype as $key=>$value){
                $deletehistory = History::where('user_id',Auth::id())->where('title',$value)->first();
                if(!empty($deletehistory)){
                    $deletehistory->delete();
                }
                
            $history = new History();
            $history->title = $value;
            $history->user_id = Auth::id();
            $history->filter_type = $request['filter_type'];
             $history->filter_name = $request['name'];
            $history->status = 1;
            $history->save();
            
            }
        }else{
           
            foreach($filtertype as $key=>$value){
                $deletehistory = History::where('user_id',Auth::id())->where('title',$value)->first();
                if(!empty($deletehistory)){
                    $deletehistory->delete();
                }
                
            $history = new History();
            $history->title = $value;
            $history->user_id = Auth::id();
            $history->status = 1;
            $history->filter_type = $request['filter_type'];
            $history->filter_name = $request['name'];
            $history->save();
            
            }
            }
            
        }
        
        
        if($company_list1) { ?>
            <script>
                $(document).ready(function() {
                    var table = $('#company_list3').DataTable();
                });
            </script>
            <script>
       $('#next').click(function(){
          var next = $("#next").val()
    
        $.ajax({
            type: "GET",
            url: base_url+'/search-single-company/',
            data: {
                
                page:next
            },
            beforeSend: function() {
                $('.show_filter_company_list_msg').show();
            },
            success: function (response){
                $('.show_filter_company_list_msg').hide();
                $('.show_filter_company_list').html(response);
                $('#People').hide();
                $('#Companies').hide();
                 $(".filter_search").attr("disabled", false);
            }
        });
       });
        
    
       
    </script>
    
        <table id="company_list3" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>Company</th>
                    <th>details</th>
                    <th>Action</th>
                </tr>
            </thead>
            
            <tbody>
                    <?php //Check company name is exit or not in array
                  
                    if(!empty($company_list1)){ 
                    foreach($company_list1 as $key => $company_list){
                        if(!empty($company_list->job_company_name)){
                    ?>
                    
                        <tr>
                           <td>
                            <p><strong><?php if(isset($company_list->job_company_name)) echo $company_list->job_company_name; ?></strong></p>
                            <p><?php if(isset($company_list->job_company_location_name)) echo $company_list->job_company_location_name; ?></p>
                            <p><?php  if(isset($company_list->job_company_industry)) echo $company_list->job_company_industry; ?></p>
                            <p><?php if(isset($company_list->job_company_size)) echo $company_list->job_company_size; ?></p>
                            <p><?php if(isset($company_list->job_company_website)) echo $company_list->job_company_website; ?></p>
                          </td>
                          <td>
                              <p><?php if(isset($company_list->phone_numbers[0])) echo "Phone: ".$company_list->phone_numbers[0] ; ?></p>
                              <p><?php if(isset($company_list->emails[0]->address)) echo "Email: ".$company_list->emails[0]->address; ?></p>
                          </td>
                           <td> <?php // if(isset($company_list->_id)) echo (array)$company_list->_id; ?>
                         
                         
                                <button class="btn app-btn-primary float-end show_company_detail" data-company_id="<?php // echo @$_id['$oid']; ?>">Show Details</button>
                            </td>
                        </tr>
                        
                    <?php } } } ?>
            </tbody>

        </table>
           
  
        <?php }else{
            echo "No data Found!";
        } 
    }
    
    public function searchcompanyname(Request $request,$id){
        print_r($request->all()); die;
       $api_secret = env('API_SECRET'); 
       $api_url = env('API_URL'); 
        $url =  $api_url.''."fetchAll";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);

        $data = array(
            "api_secret" => $api_secret,
            "page" => 1,
            "limit" => 1000,
            "order" => "ASC",
            "hasMore"=> true,

        );
        
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        $contents = curl_exec($ch);
        $company_list1 = json_decode($contents);
        
      $filtername=   $request->filter_name;
          $company_list1 = collect((array)$company_list1->data)->where('job_company_name',$request->filter_name)->all();
         
   if($company_list1) { ?>
            <script>
                $(document).ready(function() {
                    var table = $('#company_list3').DataTable();
                });
            </script>
        <table id="company_list3" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>Company</th>
                    <th>details</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                    <?php //Check company name is exit or not in array
                  
                    if(!empty($company_list1)){ 
                    foreach($company_list1 as $key => $company_list){
                    ?>
                     
                        <tr>
                           <td>
                            <p><strong><?php if(isset($company_list->job_company_name)) echo $company_list->job_company_name; ?></strong></p>
                            <p><?php if(isset($company_list->job_company_location_name)) echo $company_list->job_company_location_name; ?></p>
                            <p><?php  if(isset($company_list->job_company_industry)) echo $company_list->job_company_industry; ?></p>
                            <p><?php if(isset($company_list->job_company_size)) echo $company_list->job_company_size; ?></p>
                            <p><?php if(isset($company_list->job_company_website)) echo $company_list->job_company_website; ?></p>
                          </td>
                          <td>
                              <p><?php if(isset($company_list->phone_numbers[0])) echo "Phone: ".$company_list->phone_numbers[0] ; ?></p>
                              <p><?php if(isset($company_list->emails[0]->address)) echo "Email: ".$company_list->emails[0]->address; ?></p>
                          </td>
                           <td> 
                           <?php $_id = (array)$company_list->_id; ?>
                                <button class="btn app-btn-primary float-end show_company_detail" data-company_id="<?php echo $_id['$oid']; ?>">Show Details</button>
                            </td>
                        </tr>
                        
                    <?php } } ?>
            </tbody>
        </table>
        <?php } 
    }
    
    public function SavedHistory(Request $request){

       $filterdata1 =  $request['filterdata1'][0];
       $job_title1 = str_replace($filterdata1, "job_company_name", $filterdata1);
       $f_key1 = str_replace("1", "job_company_name", $filterdata1);
      // print_r($f_key1); die;
        $filterdata2 =  $request['filterdata2'][0];
       $job_title2 = str_replace($filterdata2, "job_company_location_name", $filterdata2);
        $f_key2 = !empty($request['filterdata2'][0]?2:'');
        
        $filterdata3 =  $request['filterdata3'][0];
       $job_title3 = str_replace($filterdata3, "job_company_industry", $filterdata3);
       $f_key3 = !empty($request['filterdata3'][0]?3:'');
       
        $filterdata4 =  $request['filterdata4'][0];
       $job_title4 = str_replace($filterdata4, "job_company_size", $filterdata4);
       $f_key4 = !empty($request['filterdata4'][0]?4:'');
       
        $filterdata5 =  $request['filterdata5'][0];
       $job_title5 = str_replace($filterdata5, "job_company_founded", $filterdata5); 
              $f_key5 = !empty($request['filterdata5'][0]?5:'');

        $filterdata6 =  $request['filterdata6'][0];
       $job_title6 = str_replace($filterdata6, "job_title", $filterdata6);
              $f_key6 = !empty($request['filterdata6'][0]?6:'');

        $filterdata7 =  $request['filterdata7'][0];
       $job_title7 = str_replace($filterdata7, "job_company_location_country", $filterdata7);
              $f_key7 = !empty($request['filterdata7'][0]?7:'');

       
        $filterdata8 =  $request['filterdata8'][0];
       $job_title8 = str_replace($filterdata8, "job_title_role", $filterdata8);
              $f_key8 = !empty($request['filterdata8'][0]?8:'');

       
        $filterdata9 =  $request['filterdata9'][0];
       $job_title9 = str_replace($filterdata9, "job_title_role", $filterdata9);
              $f_key9 = !empty($request['filterdata9'][0]?9:'');

       
        $filterdata10 =  $request['filterdata10'][0];
       $job_title10 = str_replace($filterdata10, "job_title", $filterdata10);
      $f_key10 = !empty($request['filterdata10'][0]?10:'');

       
       $totalvalue = array_merge(@$job_title1,@$job_title2,@$job_title3,@$job_title4,@$job_title5,@$job_title6,@$job_title7,@$job_title8,@$job_title9,@$job_title10);
       
//         $totalkey = array_merge(@$f_key1,@$f_key2,@$f_key3,@$f_key4,@$f_key5,@$f_key6,@$f_key7,@$f_key8,@$f_key9,@$f_key10);
// print_r($totalvalue); die;
        
        //str_replace(".", "-", $var1)

        $title = $request['job_title'];
        
      $substr=   substr(str_replace('×', ', ', $title), 1);
       
      $arraydata = explode(",",$substr);
      $alltitle =  implode(",",array_filter($totalvalue));
      
      $expdata = explode(",",$alltitle);
      
    //   $allkeys =  implode(",",array_filter($totalkey));
    //   $filter_key = explode(",",$allkeys);
        
         $save_name = $request['save_name'];
          $filtertype = $request['job_title'];
          $status = $request['status'];
          
          if($request['status'] == 1){
              foreach($arraydata as $key=>$value){
                $storehistory = new SaveHistory();
                $storehistory->title = $value;
                $storehistory->user_id = Auth::id();
                $storehistory->filter_type = $expdata[$key];
                $storehistory->filter_name = $expdata[$key];
               //  $storehistory->filter_key = $filter_key[$key];
                $storehistory->save_name = $save_name;
                $storehistory->status = $status;
                $storehistory->save();
            }
          }else{
               
              $savehistory = SaveHistory::where('user_id',Auth::id())->where('save_name',$save_name)->first();
             
              foreach($arraydata as $key=>$value){
                $storehistory = new SaveHistory();
                $storehistory->title = $value;
                $storehistory->user_id = Auth::id();
                $storehistory->filter_type = $expdata[$key];
                $storehistory->filter_name = $expdata[$key];
               // $storehistory->filter_key = $filter_key[$key];
                $storehistory->save_name = $savehistory['save_name'];
                $storehistory->status = $status;
                $storehistory->save();
            }
          }
          
         
       
    }
    
    public function RemoveSavedHistory(Request $request,$savename){
       
        $savehistory =DB::table("save_history")->whereIn('save_name',explode(",",$savename))->delete();
          return redirect('/prospecting'); 
    }
    
    public function RenameSavedHistory(Request $request,$savename){

        $savehistory = SaveHistory::where('save_name',$savename)->get()->toArray();
        //dd($savehistory);
        foreach($savehistory as $key => $value){
            $checkhistory = SaveHistory::where('save_name',$value['save_name'])->first();
            $checkhistory->save_name=$request->save_name;
            $checkhistory->save();
        }
       
        return redirect('/prospecting'); 
       
    }
    
      public function RemoveHistory(Request $request,$id){
     
        $deletehistory = History::where('user_id',Auth::id())->where('id',$id)->delete();
          return redirect('/prospecting'); 
    }
    
}
